-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 17, 2021 at 08:08 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `job`
--

-- --------------------------------------------------------

--
-- Table structure for table `application`
--

CREATE TABLE `application` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `qualification` varchar(255) NOT NULL,
  `technology` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `application`
--

INSERT INTO `application` (`id`, `name`, `qualification`, `technology`) VALUES
(1, 'Ankur', 'BCA', 'PHP,Javascript,Go'),
(2, 'Anil', 'Select', 'PHP,Javascript,Go'),
(3, 'Aman', 'BCA', 'PHP,Javascript'),
(4, 'Manu', 'BCA', 'Go'),
(5, 'Mantosh', 'BCA', 'PHP,Javascript'),
(6, 'Varun', 'B-TECH', 'PHP,Javascript'),
(7, 'Govardhan', 'BCA', 'PHP,Javascript'),
(8, 'Pawan', 'B-TECH', 'PHP,Javascript');

-- --------------------------------------------------------

--
-- Table structure for table `experience`
--

CREATE TABLE `experience` (
  `id` int(11) NOT NULL,
  `app_id` int(20) NOT NULL,
  `comapany_name` varchar(255) NOT NULL,
  `jobstartdate` date NOT NULL,
  `companycity` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `experience`
--

INSERT INTO `experience` (`id`, `app_id`, `comapany_name`, `jobstartdate`, `companycity`) VALUES
(1, 1, 'MATRID', '2021-06-03', 'Chandigarh'),
(2, 1, 'Tcs', '2021-06-30', 'Chandigarh'),
(3, 2, 'Genpact', '2021-06-04', 'Chandigarh'),
(4, 2, 'Tech mahindra', '2021-06-10', 'Chandigarh'),
(5, 3, 'Wipro', '2012-06-04', 'Chandigarh'),
(6, 3, 'Ibm', '2021-06-25', 'Chandigarh'),
(7, 4, 'Apple', '2021-06-09', 'Chandigarh'),
(8, 4, 'Facebook', '2021-06-24', 'Banglore'),
(9, 5, 'Paytm', '2021-06-16', 'Noida'),
(10, 5, 'Exl service', '2021-06-16', 'Noida'),
(11, 6, 'Tesla', '2008-02-12', 'Banglore'),
(12, 7, 'Ibm', '2013-10-11', 'Chandigarh'),
(13, 8, 'txc', '2021-06-26', 'Chandigarh');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `application`
--
ALTER TABLE `application`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `experience`
--
ALTER TABLE `experience`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `application`
--
ALTER TABLE `application`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `experience`
--
ALTER TABLE `experience`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
