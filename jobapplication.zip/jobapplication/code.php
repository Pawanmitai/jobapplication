<?php
session_start();
$conn=new mysqli('localhost','root','','job');
if(isset($_POST['submit']))
{
	$data=$_POST;
	// echo "<PRE>";
	// print_r($data);
	
	if(isset($data))
	{
		$name=$data['name'];
		$qualification=$data['qualification'];
		$arr=$data['check'];
		$technology=implode(',',$arr);
		//echo $technology;

		$sql="insert into application(id,name,qualification,technology)values('','$name','$qualification','$technology')";
		$inserted=mysqli_query($conn,$sql);
		$last_id=$conn->insert_id;
		
		$company_name=$data['companyname'];
		$jobstartdate=$data['jobstartdate'];
		$companycity=$data['companycity'];
		foreach ($company_name as $key => $value) 
		{
				 $sql2="insert into experience(id,app_id,comapany_name,jobstartdate,companycity)values('','$last_id','$value','".$jobstartdate[$key]."','".$companycity[$key]."')";
				$inserted2=mysqli_query($conn,$sql2);

		}
		
		$_SESSION['status']="Job Application Submitted Successfully";
		header('location:index.php');


	}


	

}
?>