<?php
//session_start();
$conn=new mysqli('localhost','root','','job');

$sql="SELECT * FROM application as app join experience as ex ON app.id=ex.app_id where app.technology like '%php%' AND ex.companycity='Chandigarh' AND CURRENT_DATE-ex.jobstartdate>3*365";
    $fetch=mysqli_query($conn,$sql);


?>
<!DOCTYPE html>
<?php session_start();?>
    <html lang="en">
    <head>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js"></script>
        <!-- <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css"> -->
       
    </head>
    <style type="text/css">
        .heading{
            padding-top: 1pc;
            padding-bottom: 1pc;
            background-color: #fff;
            color: #4F5155;
            font-size: 30px;

        }
        .padding{
            padding-top: 1pc;
        }

    </style>
    <body>

        
            <div class="container">
                
                    <div class="co-md-12 mb-3 heading">
                        <center>Candidate Report <br> Which having above 3 year experience in PHP Technology </center>
                    </div>
                    <div class="co-md-12 mb-3 heading text-right">
                        <a href="index.php">Go back</a>
                    </div>
                    <div class="table-responsive">
                      <table class='table  table-bordered'>
                          <tr style="background-color: #dcdcdc">
                              <td>Name</td>
                              <td>Qualification</td>
                              <td>Technology</td>
                              <td>Company Name</td>
                              <td>Company City</td>
                              <td>Job Start Date</td>
                          </tr>
                      <?php
                            while($row=mysqli_fetch_array($fetch))
                            {
                      ?>
                          <tr style="background-color: #efefef">
                              <td><?php echo $row['name']?></td>
                              <td><?php echo $row['qualification']?></td>
                              <td><?php echo $row['technology']?></td>
                              <td><?php echo $row['comapany_name']?></td>
                              <td><?php echo $row['companycity']?></td>
                              <td><?php echo $row['jobstartdate']?></td>
                          </tr>
                      <?php }?>
                      </table>
                    </div>
                   
                        
                    
            </div>
            <center><h3>All Job Application</h3></center>
            <div>
              
            </div>
            <div id="example">
               <div class="table-responsive">
                      <table class='table  table-bordered'>
                          <tr style="background-color: #dcdcdc">
                              <td>Name</td>
                              <td>Qualification</td>
                              <td>Technology</td>
                              
                          </tr>
                      <?php
                        $sql1="SELECT * FROM application";
                        $fetch1=mysqli_query($conn,$sql1);
                      
                            while($rows=mysqli_fetch_array($fetch1))
                            {
                      ?>
                          <tr style="background-color: #efefef">
                              <td><?php echo $rows['name']?></td>
                              <td><?php echo $rows['qualification']?></td>
                              <td><?php echo $rows['technology']?></td>
                              <!-- <td><?php echo $rows['comapany_name']?></td>
                              <td><?php echo $rows['companycity']?></td>
                              <td><?php echo $rows['jobstartdate']?></td> -->
                          </tr>
                      <?php }?>
                      </table>
            </div>
        
    </body>
     <!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> -->
     <script src="https://code.jquery.com/jquery-3.6.0.min.js" ></script>
    </html>
    <script type="text/javascript">
      $(document).ready(function(){
        $('#example').Datatable();
      });
    </script>
    
