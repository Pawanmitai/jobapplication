<!DOCTYPE html>
<?php session_start();?>
    <html lang="en">
    <head>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js"></script>
        <!-- <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css"> -->
       
    </head>
    <style type="text/css">
        .heading{
            padding-top: 1pc;
            padding-bottom: 1pc;
            background-color: #fff;
            color: #4F5155;
            font-size: 30px;

        }
        .padding{
            padding-top: 1pc;
        }

    </style>
    <body>

        
            <div class="container">
                <center>
                    <?php if(isset($_SESSION['status'])){?>
                    <div class="alert alert-success">
                        <?php echo $_SESSION['status'];
                            unset($_SESSION['status']);
                        ?>
                    </div>
                    <?php }?>
                </center>
                    <div class="co-md-12 mb-3 heading">
                        <center>Job Application</center>
                    </div>
                    <div class="co-md-12 mb-3 heading text-right">
                        <a href="next.php">See a Report of Candidate</a>
                    </div>
                        <form method="post" action="code.php">
                              <div class="row">
                                <div class="col-md-3 mb-3">
                                  <label for="validationDefault01">Your name</label>
                                  <input type="text" name="name" class="form-control" id="validationDefault01" placeholder="First name"  required>
                                </div>
                                
                              </div>
                              <div class="row padding">
                                <div class="col-md-3 mb-3">
                                    <label for="validationDefault02">Qualification</label>
                                    <select  name="qualification" class="custom-select custom-select-sm form-control" required>
                                      <option selected>Select</option>
                                      <option value="B.SC">B.SC</option>
                                      <option value="BCA">BCA</option>
                                      <option value="B-TECH">B-TECH</option>
                                      <option value="M-TECH">M-TECH</option>
                                      <option value="MCA">MCA</option>
                                      <option value="M.SC">M.SC</option>
                                    </select>
                                </div>
                              </div>
                              <div class="row padding">
                                <div class="col-md-6 mb-3">
                                    <label for="validationDefault02">Technologies You Know</label>
                                    <div class="custom-control custom-checkbox">
                                      <input type="checkbox" name="check[]" value="PHP" class="custom-control-input" id="customCheck1">
                                      <label>PHP</label>
                                      <input type="checkbox" name="check[]" value="Javascript" class="custom-control-input" id="customCheck1">
                                      <label>Javascript</label>
                                      <input type="checkbox" name="check[]" value="Go" class="custom-control-input" id="customCheck1">
                                      <label>Go</label>
                                      <input type="checkbox" name="check[]" value="Python" class="custom-control-input" id="customCheck1">
                                      <label>Python</label>
                                      <input type="checkbox" name="check[]" value="Ruby" class="custom-control-input" id="customCheck1">
                                      <label>Ruby</label>
                                      <input type="checkbox" name="check[]" value="Scala" class="custom-control-input" id="customCheck1">
                                      <label>Scala</label>
                                      <input type="checkbox" name="check[]" value="Mysql" class="custom-control-input" id="customCheck1">
                                      <label>Mysql</label>
                                      <input type="checkbox" name="check[]" value="Oracle" class="custom-control-input" id="customCheck1">
                                      <label>Oracle</label>
                                    </div>

                                </div>
                              </div>

                              <div class="row padding element" id="experience_1">
                                
                                <div class="col-md-3 mb-3">
                                    <label for="validationDefault02">Experience</label>
                                    <input type="text" name="companyname[]" class="form-control" id="validationDefault01" placeholder="Company Name" required >
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label for="validationDefault02">Job start</label>
                                  <input type="date" name="jobstartdate[]" class="form-control" id="validationDefault01" placeholder="First name" required>
                                </div>
                                <div class="col-md-3 mb-3">  
                                    <label for="validationDefault01">Company City</label>
                                    <select name="companycity[]" class="custom-select custom-select-sm form-control" required>
                                      <option selected>Select</option>
                                      <option value="Banglore">Banglore</option>
                                      <option value="Chandigarh">Chandigarh</option>
                                      <option value="Delhi">Delhi</option>
                                      <option value="Mumbai">Mumbai</option>
                                      <option value="Pune">Pune</option>
                                      <option value="Noida">Noida</option>
                                    </select>
                                </div>
                              </div>
                              <div class="row padding" id="addmore">
                                <a class="btn btn-primary " onclick="addmore();">Add More</a>
                                
                              </div>
                              <div class="row padding">
                              <button class="btn btn-primary" type="submit" name="submit">Submit form</button>
                                
                              </div>
                        </form>
                    
            </div>
        
    </body>
     <!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> -->
     <script src="https://code.jquery.com/jquery-3.6.0.min.js" ></script>
    </html>

    <script type="text/javascript">
        function addmore() {
           
            var total_row=$(".element").length;
            var lastid=$(".element:last").attr("id");
            //alert(lastid);
            var split_id=lastid.split('_');
            var nextindex=Number(split_id[1])+1; 
            var max=5;
           // alert(nextindex);
                if(total_row<max)
                {
                  $(".element:last").after('<div class="row padding element" id="experience_'+nextindex+'"><div class="row padding"> <a class="btn btn-warning remove" id="remove_'+nextindex+'" onclick="remove(this);">Remove</a> </div> <div class="col-md-3 mb-3"> <label for="validationDefault02">Experience</label> <input type="text" name="companyname[]" class="form-control" id="validationDefault01" placeholder="Company Name" > </div> <div class="col-md-3 mb-3"> <label for="validationDefault02">Job start</label> <input type="date" name="jobstartdate[]" class="form-control" id="validationDefault01" placeholder="First name"> </div> <div class="col-md-3 mb-3"> <label for="validationDefault01">Company City</label> <select name="companycity[]" class="custom-select custom-select-sm form-control"> <option selected>Select</option> <option value="Banglore">Banglore</option> <option value="Chandigarh">Chandigarh</option> <option value="Delhi">Delhi</option> <option value="Mumbai">Mumbai</option> <option value="Pune">Pune</option> <option value="Noida">Noida</option> </div> </div> ');
                }
            
        }

        function remove(v)
        {    
            var id=$(v).attr("id");
            var split_id=id.split('_');  
            var del=split_id[1];
            $('#experience_'+del).remove();
        }
    </script>