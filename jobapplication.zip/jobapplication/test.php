<!-- end document-->
<label>Upload (600*500)</label><br>


<input class=" au-input au-input--full" type="file" name="main_image">
<span class="add"> Click to Addmore (600*500)</span><br>

 <input class="element" type="file" id="img_1" name="imgs[]" ><br> 


<script type="text/javascript">
  $('.add').click(function(){
    
    
    var total_row=$(".element").length;
    var lastid=$(".element:last").attr("id");
    var split_id=lastid.split('_');

    var nextindex=Number(split_id[1])+1;
    var max=3;
  


    if(total_row<max)
    {
      $(".element:last").after("<input type='file' class=' element form-control' id='img_"+ nextindex +"' name='imgs[]'>");
      
      
    }

  });
  $(".remove").click(function(){
    // var id=this.id;
    // var split_id=id.split('_');
    // var del=split_id[1];
    // document.write(id);
    // //$("#img_"+del).remove();
     alert('hai');
  });
  
</script>